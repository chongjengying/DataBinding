package com.example.databinding

data class Contact (var name: String = "", var phone: String = "") { //Just need two parameters, no need constructor, getter, setter all those

}